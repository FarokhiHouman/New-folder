﻿cPump),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (HeatExchanger),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (Junction),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (MultiphaseBooster),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (MultiplierAdder),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (ThreePhaseSeparator),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (TwoPhaseSeparator),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (Sink),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (Source),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (OneSubseaWetGasCompressorParameterBag),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (OneSubseaBoosterParameterBag),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.SurfaceEquipmentTab)
    },
    {
      typeof (GasLiftInjection),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.ArtificialLiftTab)
    },
    {
      typeof (VpcGasLiftValve),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.ArtificialLiftTab)
    },
    {
      typeof (GasLiftInjectionSeabedImpl),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.ArtificialLiftTab)
    },
    {
      typeof (Slb.Production.Engineering.Model.StandardDomain.ESP),
      (Func<object, WellEditorTabs>) (o => WellEditorTabs.ArtificialLiftTab)
    },
    {
      typeof (ESPMotorCatalogData),
      (Func<o
