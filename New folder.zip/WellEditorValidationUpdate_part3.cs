﻿leted -= new EventHandler<DomainObjectEventGroup>(this.WllStringCreatedDeleted);
    TubingSectionAccessor.GetFacadeAccessor(service).Created -= new EventHandler<DomainObjectEventGroup>(this.WllStringCreatedDeleted);
  }
}

