﻿.TailTop:
        return firstNode.ParentString.IsValidTubing ? flag : this.IsInjection;
      default:
        return true;
    }
  }
}

