﻿eVisible = "FlowLineVisible";
  public const string LabelVisible = "LabelVisible";
  public const string DepthVisible = "DepthVisible";
  public const string Wellbore1D = "1D";
  public const string Wellbore2D = "2D";
  public const string GasLiftInjection = "GasLiftInjection";
  public const string ESP = "ESP";
  public const string PCP = "PCP";
  public const string RodPump = "RodPump";
  public const string UserEqp = "UserEquipment";
}

